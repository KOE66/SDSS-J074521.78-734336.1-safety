a safety version for SDSS J074521.78+734336.1.exe by pankoza



CREDITS TO PANKOZA FOR THE ORIGINAL!